# Databricks notebook source
from DatabricksHelper.ServiceUtils import PipelineUtils
import json
import uuid

# COMMAND ----------

p_u = PipelineUtils()
params = p_u.init_run_notebook_params()
if not params.pipeline_run_id:
    params.pipeline_run_id = str(uuid.uuid4())

params.task_load_info = json.dumps(p_u.get_task_values())
print(params)

# COMMAND ----------

#根据reload_info生成reload_info
#循环多组load_id
#for i in [1,2]:
reload_info = None
if params.reload_info and isinstance(params.reload_info, str):
    reload_info = json.loads(params.reload_info)
print(reload_info)
if reload_info and isinstance(reload_info, dict):
    for key, value in reload_info.items():
        print(value)
        table = value["query"]
        rows = spark.sql(f"select _load_id, max(_load_time) as _load_time, count(1) as _count from ({table}) t group by _load_id order by _load_time").collect()
        index = 0
        loads = []
        row_count = 0
        batch = value["batch_size"]
        for row in rows:
            index += 1
            load_id = row["_load_id"]
            count = row["_count"]
            loads.append(load_id)
            row_count += count
            if row_count >= batch or index >= len(rows):
                load_ids = ', '.join([f"'{item}'" for item in loads])
                #print(load_ids, row_count)
                params.reload_info = json.dumps({f"{key}": f"select * from ({table}) t where _load_id in ({load_ids})"})
                print(params)
                dbutils.notebook.run(params.notebook_path, params.notebook_timeout, arguments=vars(params))
                row_count = 0
                loads = []

