# Databricks notebook source
from DatabricksHelper.Service import Pipeline,Reload
from DatabricksHelper.ServiceUtils import PipelineUtils
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
import json

# COMMAND ----------

p_u = PipelineUtils()
params = p_u.init_optimize_params()
print(params)
p = Pipeline(params.ref_id, params.pipeline_run_id, params.default_catalog, params.pipeline_name)

# COMMAND ----------

optimize_tables = json.loads(params.optimize_tables)
#params.optimize_tables
#[{"table_name":"temp.businesspartner", "vacuum_days_interval": 1, "optimize_days_interval": 1, "vacuum": true, "optimize": true}]

# COMMAND ----------

for option in optimize_tables:
    if option:
        tables = option.get("tables", [])
        vacuum_days_interval = option.get("vacuum_days_interval", 1)
        optimize_days_interval = option.get("optimize_days_interval", 1)
        vacuum = option.get("vacuum", True)
        optimize = option.get("optimize", True)
        if isinstance(tables, list):
            for table_name in tables:
                if table_name and vacuum:
                    p.vacuum_table(table_name=table_name, days=vacuum_days_interval)
                if table_name and optimize:
                    p.optimize_table(table_name=table_name, days=optimize_days_interval)

        table_name = option.get("table_name", None)
        if table_name and vacuum:
            p.vacuum_table(table_name=table_name, days=vacuum_days_interval)
        if table_name and optimize:
            p.optimize_table(table_name=table_name, days=optimize_days_interval)
