# Databricks notebook source
# MAGIC %md
# MAGIC # 将已经存在于temp 表的数据，根据relaod info 重新加载到silver

# COMMAND ----------

from DatabricksHelper.ServiceUtils import PipelineUtils
import json
import uuid

# COMMAND ----------

p_u = PipelineUtils()
params = p_u.init_run_load_notebook_params()
if not params.pipeline_run_id:
    params.pipeline_run_id = str(uuid.uuid4())

params.task_load_info = json.dumps(p_u.get_task_values())
print(params)

# COMMAND ----------

#{"businesspartner":{"query":"select * from evacatalog.temp.businesspartner where _load_time > '2024-7-22'", "batch_size":10000, "partition_size":50}}
p_u.reload(params.notebook_path, params.notebook_timeout, params.reload_info, vars(params))