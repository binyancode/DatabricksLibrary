from datetime import datetime
import json
import uuid
from pyspark.sql.functions import *
from pyspark.sql.types import *
import pyodbc
import linecache
import sys

class Pipeline:
  def _t(self, df):
    tmp_guid = str(uuid.uuid4().hex)
    df.createOrReplaceTempView(tmp_guid)
    return tmp_guid

  #time watcher，用于监控运行时长
  def _w(self, mark):
    if self.watcher.get(mark) is None:
      self.watcher[mark] = datetime.now()
    elif type(self.watcher[mark]) is datetime:
      finishtime = datetime.now()
      elapsed = finishtime - self.watcher[mark]
      duration =  int(elapsed.total_seconds())
      self.watcher[mark] = duration
    return self.watcher

  #运行时数据处理行数
  def _c(self, mark, cnt):
    if self.counter.get(mark) is None:
      self.counter[mark] = cnt
    else:
      self.counter[mark] = self.counter[mark] + cnt
    return self.counter

  #运行子notebook，并自动记录返回日志
  def _r(self, path, timeount = 3600, params = None):
    if params is None:
      params = {}
    params["runtime_id"] = self.runtime_id
    params["parent_process"] = self.process_name
    params["process_id"] = self.process_id
    sub = json.loads(self.dbutils.notebook.run(path, timeount, params))
    for dw_copy_data in sub["DW_COPY_DATA"]:
      self.dw_copy_data.append(dw_copy_data)
    self.sub_output.append(sub)
    if sub["STATUS"] == "Failed":
      raise Exception(f"Sub notebook exception:{path}")

  def _dl(self, output):
    with open(self.config, "r") as config_reader:
      config = json.loads(config_reader.read())
    value = json.loads(output)
    self._dq("LogSqlDatabase", 'INSERT INTO [dbo].[DatabricksRuntimeLogs]([SESSION_ID], [LOG_TIME],[START_TIME],[RUNTIME_ID],[PROCESS_NAME],[PROCESS_ID],[PARENT_PROCESS],[TOTAL_DURATION],[STATUS],[VALUE]) VALUES (?,?,?,?,?,?,?,?,?,?)', [self.session_id, datetime.now(), self.start_time, value["RUNTIME_ID"], value["PROCESS_NAME"], value["PROCESS_ID"], value["PARENT_PROCESS"], value["DURATION"]["TOTAL_DURATION"], value["STATUS"], output])

  def _dq(self, config_name, query, params = []):
    try:
      with open(self.config, "r") as config_reader:
        config = json.loads(config_reader.read())
      conn = pyodbc.connect('DRIVER={ODBC Driver 17 for SQL Server};'
                             f'SERVER={config[config_name]["Server"]};'
                             f'DATABASE={config[config_name]["Database"]};UID={config[config_name]["User"]};'
                             f'PWD={self.dbutils.secrets.get(scope = config[config_name]["PasswordSecretScope"], key = config[config_name]["PasswordSecretKey"])}')
      conn.autocommit = True
      return conn.execute(query, params)
      #conn.commit()
    finally:
      try:
        conn.close()
      except NameError: None
      
      
  def _l(self, key, value):
    self.logs[key] = value

  #输出日志
  def _o(self):  
    self._w("TOTAL_DURATION")
    if len(self.errors) > 0:
      status = "Failed"
    else:
      status = "Succeeded"
    for sub in self.sub_output:
      if sub["STATUS"] == "Failed":
        status = "Failed"
        break
    json_return = json.dumps({
      "SESSION_ID" : self.session_id,
      "RUNTIME_ID" : self.runtime_id,
      "START_TIME" : self.start_time,
      "PROCESS_NAME" : self.process_name,
      "PROCESS_ID" : self.process_id,
      "DURATION": self.watcher,
      "LOAD_CNT": self.counter,
      "ERROR_MSG" : self.errors,
      "STATUS" : status,
      "PARENT_PROCESS": self.parent_process,
      "SUB_PROCESS" : self.sub_output,
      "LOGS": self.logs,
      "TEMP_TABLE": self.temp_table,
      "DW_COPY_DATA": self.dw_copy_data
    }, default=str)
    #self._dl(json_return)
    return self.dbutils.notebook.exit(json_return)
  
  def _e(self, error = None):
    exc_type, exc_obj, tb = sys.exc_info()
    if exc_type is not None:
      f = tb.tb_frame
      lineno = tb.tb_lineno
      filename = f.f_code.co_filename
      linecache.checkcache(filename)
      line = linecache.getline(filename, lineno, f.f_globals)
      self.errors.append(f'Exception In ({filename}, Line {lineno} "{line.strip()}"): {exc_obj}')
    else:
      self.errors.append(error)

  def _dw(self, df, sch, tab, trun = "true", mode = "append"):
    with open(self.config, "r") as config_reader:
      config = json.loads(config_reader.read())
    config_name = "DatabricksConnectSynapse"
    self.spark.conf.set(
      f'fs.azure.account.key.{config[config_name]["TempStorageAccount"]}',
      self.dbutils.secrets.get(scope = config[config_name]["TempStorageKeySecretScope"], key = config[config_name]["TempStorageKeySecretKey"]))

    temp_tab = f'{sch}.{tab}'
    if trun == "true":
      self._dq(config_name, f"""
      if object_id('[{sch}].[{tab}]') is not null
          truncate table [{sch}].[{tab}]
      """)
    #self._dwq(f"if object_id('{temp_tab}') is not null  drop table {temp_tab}")
    df.write \
     .format("com.databricks.spark.sqldw") \
     .option("url", f'jdbc:sqlserver://{config[config_name]["Server"]}:1433;database={config[config_name]["Database"]};user={config[config_name]["User"]};password={self.dbutils.secrets.get(scope = config[config_name]["PasswordSecretScope"], key = config[config_name]["PasswordSecretKey"])};encrypt=true;trustServerCertificate=false;hostNameInCertificate={config[config_name]["HostNameInCertificate"]};loginTimeout={config[config_name]["Timeout"]};') \
     .option("forwardSparkAzureStorageCredentials", "true") \
     .option("dbTable", temp_tab) \
     .option("truncate",trun) \
     .mode(mode) \
     .option("tempDir", f'wasbs://{config[config_name]["TempStorageContainer"]}@{config[config_name]["TempStorageAccount"]}/{config[config_name]["TempStoragePath"]}/{tab}') \
     .save()
    self.temp_table[tab] = temp_tab
    return temp_tab
  
  def _dwd(self, df, sch, tab, trun = "true"):
    with open(self.config, "r") as config_reader:
      config = json.loads(config_reader.read())
    config_name = "SynapseCopy"
    tempDir = f'{config[config_name]["TempStorageFilesystem"]}@{config[config_name]["TempStorageAccount"]}/{config[config_name]["TempStoragePath"]}/{tab}/{datetime.now().strftime("%Y-%m-%d")}/{str(uuid.uuid4())}'
    spark.conf.set(f'fs.azure.account.auth.type.{config[config_name]["TempStorageAccount"]}', "OAuth")
    spark.conf.set(f'fs.azure.account.oauth.provider.type.{config[config_name]["TempStorageAccount"]}', "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider")
    spark.conf.set(f'fs.azure.account.oauth2.client.id.{config[config_name]["TempStorageAccount"]}', config[config_name]["TempStorageClientID"])
    spark.conf.set(f'fs.azure.account.oauth2.client.secret.{config[config_name]["TempStorageAccount"]}', self.dbutils.secrets.get(scope = config[config_name]["TempStorageClientSecretScope"], key = config[config_name]["TempStorageClientSecretKey"]))
    spark.conf.set(f'fs.azure.account.oauth2.client.endpoint.{config[config_name]["TempStorageAccount"]}', config[config_name]["TempStorageOAuthEndpoint"])
    tempDir = str(uuid.uuid4())
    df \
    .write \
    .format("parquet") \
    .save(f'abfss://{config[config_name]["TempStorageFilesystem"]}@{config[config_name]["TempStorageAccount"]}/{config[config_name]["TempStoragePath"]}/{tab}/{datetime.now().strftime("%Y-%m-%d")}/{tempDir}')
    self.dw_copy_data.append(
      {
        "TABLE": f'[{sch}].[{tab}]',
        "TRUNCATE": trun,
        "MODE": mode,
        "DATA": f'https://{config[config_name]["TempStorageAccount"]}/{config[config_name]["TempStorageFilesystem"]}/{config[config_name]["TempStoragePath"]}/{tab}/{datetime.now().strftime("%Y-%m-%d")}/{tempDir}',
        "CLIENT_ID": config[config_name]["TempStorageClientID"],
        "OAUTH_ENDPOINT": config[config_name]["TempStorageOAuthEndpoint"],
        "CLIENT_SECRET_CERTIFICATE": config[config_name]["TempStorageClientSecretCertificate"],
        "CLIENT_SECRET_SYMMETRIC_KEY": config[config_name]["TempStorageClientSecretSymmetricKey"],
        "CLIENT_SECRET_ENCRYPTED_BINARY": config[config_name]["TempStorageClientSecretEncryptedBinary"]
      })
  
  def __init__(self, _spark, _dbutils, _config, _runtime_id = None, _process_name = None, _parent_process = None):
    #global start_time, process_name, runtime_id, parent_process, watcher, counter, errors, sub_output, dbutils, logs, process_id
    self.session_id = str(uuid.uuid4())
    self.spark = _spark
    self.dbutils = _dbutils
    self.config = _config
    if _runtime_id is None:
      self.dbutils.widgets.text("runtime_id", "")
      _runtime_id = self.dbutils.widgets.get("runtime_id")
    if _parent_process is None:
      self.dbutils.widgets.text("parent_process", "")
      _parent_process = self.dbutils.widgets.get("parent_process")
    if _process_name is None:
      _process_name = self.dbutils.notebook.entry_point.getDbutils().notebook().getContext().notebookPath().get()
    self.dbutils.widgets.text("process_id", "")
    self.process_id = self.dbutils.widgets.get("process_id")  
    if self.process_id is None or self.process_id == "":
      self.process_id = str(uuid.uuid4())
    self.logs = {}
    self.start_time = datetime.now()
    self.process_name = _process_name
    self.runtime_id = _runtime_id
    self.parent_process = _parent_process
    self.watcher = {}
    self.counter = {}
    self.temp_table = {}
    self.errors = []
    self.sub_output = []
    self.dw_copy_data = []
    self._w("TOTAL_DURATION")

    

